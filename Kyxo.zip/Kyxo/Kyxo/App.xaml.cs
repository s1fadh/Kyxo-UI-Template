﻿using System.Windows;

namespace Kyxo
{
    public partial class App : Application
    {
    }
}
