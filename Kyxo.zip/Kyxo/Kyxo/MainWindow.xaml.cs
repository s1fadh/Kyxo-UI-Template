﻿using System.Windows;

namespace Kyxo
{
    public partial class MainWindow : Window
    {
        // Kyxo Softworks (c) 2020-2021
        /* - Make sure to credit us if u were to use this template.
           - We cleared the source so gtfo skids 
           - The user interface is resizeable, we left all the styles so feel free to use it, but dont forget to credit or gonna get exposed */

        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
